import mysql.connector
mydbs=mysql.connector.connect(
    host="localhost",
    user="root",
    password="Singhcse@7")

mycursor=mydbs.cursor()
mycursor.execute("CREATE DATABASE AshishHari")