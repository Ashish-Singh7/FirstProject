from tkinter import *
import pandas as pd
import numpy as np
import mysql.connector
import tkinter.messagebox


def disp():
    mydss = mysql.connector.connect(host="localhost",
                                    user="root",
                                    password="Singhcse@7",
                                    database="AshishHari"
                                    )
    mycs = mydss.cursor()
    mycs.execute("SELECT * FROM passenger_table0")
    myresult = mycs.fetchall()
    lb1 = Listbox(top,width=100,height=10)
    lb1.place(x=600, y=150)
    for x in myresult:
        lb1.insert(1,x)

def dell():
    mydss = mysql.connector.connect(host="localhost",
    user="root",
    password="Singhcse@7",
    database="AshishHari"
     )
    mycs = mydss.cursor()

    n=var.get()
    mycs.execute("DELETE FROM passenger_table0 where name='"+var.get()+"'")
    tkinter.messagebox.showinfo("Delete Booking","1 row successfuly deleted")
    mydss.commit()


top=Tk()
top.geometry("1600x1600")
top.title("Comforming Booking")
top.configure(bg="pink")


var=StringVar()

l1=Label(top,text="Enter Name to delete record :")
l1.place(x=100,y=200)
t1=Entry(top,bd=5,textvariable=var)
t1.place(x=300,y=200)
l2=Label(top,text="WELCOME TO BOOKING PAGE",bg="cyan")
l2.place(x=480,y=100)


b1=Button(top,text="Show all Booking",height=2,width=15,bg="yellow",fg="green",
         activebackground="red",activeforeground="violet",command=disp).place(x=750,y=350)

b2=Button(top,text="Delete Booking",command=dell,height=2,width=15,bg="yellow",fg="green",
         activebackground="blue",activeforeground="violet")
b2.place(x=200,y=350)

top.mainloop()