from tkinter import*
import tkinter.messagebox as MessageBox
import mysql.connector
root=Tk()
root.geometry("600x300")
def validate():
    mydss = mysql.connector.connect(host="localhost", user="root", password="Singhcse@7", database="AshishHari")
    if(mydss):
        mycs = mydss.cursor()
        data ="SELECT * FROM logintable WHERE email = '"+v1.get()+"' AND password = '"+v2.get()+"'"
        mycs.execute(data)
        result = mycs.fetchall()
        if(result == []):
            MessageBox.showinfo("Warning", "Fill Up id and password ")
        else:
            MessageBox.showinfo("Success", "you have logged in")

root.configure(bg="light green")
title=Label(root,text="Login Booking",fg="white",bg="light green",font=("bold",19))
title.place(x=200,y=30)
uname=Label(root,text="E-mail ID",fg="white",bg="light green",font=("bold",13))
uname.place(x=100,y=80)
password=Label(root,text="Password",fg="white",bg="light green",font=("bold",13))
password.place(x=100,y=110)

v1 = StringVar()
t_uname=Entry(textvariable=v1)
t_uname.place(x=200,y=80)

v2 = StringVar()
t_pwd=Entry(textvariable=v2)
t_pwd.place(x=200,y=110)

submit=Button(root,text="Login",  command=validate)
submit.place(x=200,y=140)
root.mainloop()