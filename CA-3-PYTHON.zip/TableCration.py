import mysql.connector

mydss = mysql.connector.connect(host="localhost",
 user="root",
 password="Singhcse@7",
 database="AshishHari"
 )
new= mydss.cursor()

data = "CREATE TABLE passenger_table0 (name VARCHAR(20),age INT(50), gender INT(20), phonenumber INT(255), typeofcar INT(20), time VARCHAR(20),location VARCHAR(200) )"
new.execute(data)

