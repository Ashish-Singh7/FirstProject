from tkinter import *
import mysql.connector
import tkinter.messagebox


def create():
    e = email_value.get()
    p = password_value.get()

    if e == '' or p == '':
        tkinter.messagebox.showinfo("Warning", "Please! Fill Up all entryboxes")
    else:
        tkinter.messagebox.showinfo("Success", "you have created new account")
        mydss = mysql.connector.connect(host="localhost", user="root", password="Singhcse@7", database="AshishHari")
        if (mydss):
            mycs = mydss.cursor()
            old = "INSERT INTO logintable (email, password) VALUES(%s,%s)"
            new = (e, p)
            mycs.execute(old, new)
            mydss.commit()


root = Tk()
root.geometry("800x500")  # ("1366x768")
root.configure(bg="silver")
root.minsize(500, 500)
root.maxsize(1366, 768)
root.title("Cab Booking Application for registration")

Label(root, text="CRETE ID", width=20, bg="pink", font=("Helvatica 30 bold")).place(x=50, y=53)

email_value = StringVar()
password_value = StringVar()

email = Label(root, text="Email-Id", width=15, bg="silver", font=("Helvatica 12 bold"))
email.place(x=60, y=130)

email_entry = Entry(root, width=28, bd=5, textvariable=email_value)
email_entry.place(x=260, y=130)

password = Label(root, text="Password", width=15, bg="silver", font=("Helvatica 12 bold"))
password.place(x=60, y=180)

password_entry = Entry(root, width=28, bd=5, textvariable=password_value)
password_entry.place(x=260, y=180)

Button(root, text='click here', width=20, bg='brown', fg='white', command=create).place(x=220, y=250)

root.mainloop()