import mysql.connector

mydss = mysql.connector.connect(host="localhost",
 user="root",
 password="Singhcse@7",
 database="AshishHari"
 )
new= mydss.cursor()
data = "CREATE TABLE logintable (email VARCHAR(205), password VARCHAR(205)  )"

new.execute(data)