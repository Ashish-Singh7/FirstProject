from tkinter import *
import mysql.connector
import tkinter.messagebox


def cab():
    a = age_value.get()
    p = phone_value.get()
    n = name_value.get()
    v0 = var.get()  # gender
    v1 = var1.get()  # type of car
    t = time_value.get()
    l = location_value.get()

    if n == '' or a == '' or v0 == 0 or v1 == 0 or p == '' or t == '' or l == ' ':
        tkinter.messagebox.showinfo("Warning", "Please! Fill Up all Boxes")
    elif a != '' or p != '' or t != '':
        try:
            a = int(a)
            # n = int(n)
            p = int(p)
        except:
            tkinter.messagebox.showinfo("Warning", " plaese fill correctly!")
        else:
            tkinter.messagebox.showinfo("Success", "Booking for " + str(n) + " has been created")
            s = (f"Dear {n}, your booking is confirm from {l}  at time {t}.")
            label_2.config(text=s)
            mydss = mysql.connector.connect(host="localhost",
                                            user="root",
                                            password="Singhcse@7",
                                            database="AshishHari"
                                            )
            if (mydss):
                mycs = mydss.cursor()
                old = "INSERT INTO passenger_table0 (name ,age , gender , phonenumber , typeofcar , time, location ) VALUES(%s,%s,%s,%s,%s,%s,%s)"
                new = (n, a, v0, p, v1, t, l)
                mycs.execute(old, new)
                mydss.commit()

    else:
        pass


root = Tk()
root.geometry("1366x768")
root.configure(bg="grey")
root.minsize(500, 500)
root.maxsize(1366, 768)
root.title("Cab Booking Application")

#   left = Frame(root, width=800, height=720, bg='grey')
#  left.pack(side=LEFT)

Label(root, text="CAB BOOKING", width=20, bg="pink", font=("Helvatica 30 bold")).place(x=50, y=53)

name_value = StringVar()
age_value = StringVar()
phone_value = StringVar()
time_value = StringVar()
location_value = StringVar()

name = Label(root, text="Name", width=20, bg="grey", font=("Helvatica 12 bold"))
name.place(x=80, y=130)

name_entry = Entry(root, width=28, bd=5, textvariable=name_value)
name_entry.place(x=260, y=130)

age = Label(root, text="Age", width=28, bg="grey", font=("Helvatica 12 bold"))
age.place(x=50, y=180)

age_entry = Entry(root, width=28, bd=5, textvariable=age_value)
age_entry.place(x=260, y=180)

gender = Label(root, text="Gender", width=20, bg="grey", font=("Helvatica 12 bold"))
gender.place(x=80, y=230)
var = IntVar()
Radiobutton(root, text="Male", padx=5, bg="grey", variable=var, value=1).place(x=255, y=230)
Radiobutton(root, text="Female", padx=20, bg="grey", variable=var, value=2).place(x=310, y=230)

phonenumber = Label(root, text="PhoneNumber", width=20, bg="grey", font=("Helvatica 12 bold"), )
phonenumber.place(x=80, y=280)

phonenumber_entry = Entry(root, width=28, bd=5, textvariable=phone_value)
phonenumber_entry.place(x=260, y=280)

car = Label(root, text="TypeofCar", width=20, bg="grey", font=("Helvatica 12 bold"))
car.place(x=80, y=330)
var1 = IntVar()
Radiobutton(root, text="AC", padx=5, bg="grey", variable=var1, value=1).place(x=255, y=330)
Radiobutton(root, text="NonAC", padx=20, bg="grey", variable=var1, value=2).place(x=310, y=330)

time = Label(root, text="Time", width=20, bg="grey", font=("Helvatica 12 bold"))
time.place(x=80, y=380)

time_entry = Entry(root, width=28, bd=5, textvariable=time_value)
time_entry.place(x=260, y=380)

location = Label(root, text="Location", width=20, bg="grey", font=("Helvatica 12 bold"))
location.place(x=80, y=430)

location_entry = Entry(root, width=28, bd=5, textvariable=location_value)
location_entry.place(x=260, y=430)

Button(root, text='PROCEED', width=20, bg='brown', fg='white', command=cab).place(x=220, y=480)

label_1 = Label(root, text="Status =", font="helvatica 14 bold", bd=5, bg="silver", fg="brown")
label_1.place(x=605, y=130)

label_2 = Label(root, text="", font="helvatica 13 bold", bd=5, bg="silver")
label_2.place(x=705, y=130)

root.mainloop()